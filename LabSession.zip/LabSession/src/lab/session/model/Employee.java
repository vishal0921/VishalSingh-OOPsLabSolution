package lab.session.model;

public class Employee {
	String fName;
	String lName;

	public Employee(String FirstName, String Lastname) {
		fName = FirstName;
		fName = Lastname;
	}

	public String getFname() {
		return fName;
	}

	public void setFname(String fname) {
		fName = fname;
	}

	public String getLname() {
		return lName;
	}

	public void setLname(String lname) {
		lName = lname;
	}

	
}


