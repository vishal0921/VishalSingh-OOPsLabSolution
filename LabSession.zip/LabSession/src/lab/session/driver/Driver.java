package lab.session.driver;

import java.util.Scanner;

import lab.session.services.CredentialServices;
import lab.session.model.Employee;

public class Driver {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee employee = new Employee("Harshit", "Chaudhary");
		CredentialServices cs = new CredentialServices();
		String department;
		String emailId;
		char[] password;
		int i = 0;
		System.out.println("Please enter department from the following \n" + "1. Technical\n" + "2. Admin\n"
				+ "3. Human Resource\n" + "4. Legal");
		Scanner sc = new Scanner(System.in);
		i = sc.nextInt();

		System.out.println("Dear" + employee.getFname() + "your generated credentials are as follows	");
		switch (i) {
		case 1:
			department = "Tech";
			emailId = cs.generateEmailAddress(employee.getFname(), employee.getLname(), department);
			password = cs.generatePassword(8);
			cs.showCredentials(emailId, password);
			break;
		case 2:
			department = "Admin";
			emailId = cs.generateEmailAddress(employee.getFname(), employee.getLname(), department);
			password = cs.generatePassword(8);
			cs.showCredentials(emailId, password);
			break;
		case 3:
			department = "HR";
			emailId = cs.generateEmailAddress(employee.getFname(),employee.getLname(), department);
			password = cs.generatePassword(8);
			cs.showCredentials(emailId, password);
			break;
		case 4:
			department = "Legal";
			emailId = cs.generateEmailAddress(employee.getFname(), employee.getLname(), department);
			password = cs.generatePassword(8);
			cs.showCredentials(emailId, password);
			break;
		}
		sc.close();
	}

}
